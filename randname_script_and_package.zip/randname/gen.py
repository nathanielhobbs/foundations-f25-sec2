import random
from .words import ADJ, NOUN

def nickname(sep="-"):
    adj = random.choice(ADJ)
    noun = random.choice(NOUN)
    return f"{adj}{sep}{noun}"