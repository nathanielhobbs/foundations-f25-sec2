ADJ = ['brave', 'swift', 'quiet', 'bright']
NOUN = ['tiger', 'falcon', 'otter', 'lion']