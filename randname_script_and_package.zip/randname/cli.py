import argparse, random
from .gen import nickname

def build_parser():
    p = argparse.ArgumentParser(prog="randname", description="Generate random nicknames")

    p.add_argument("-n", '--count', type=int, default=1)
    p.add_argument('--sep', default='-')
    p.add_argument('--seed', type=int)
    return p

def main(argv):
    args = build_parser().parse_args(argv)
    if args.seed is not None:
        random.seed(args.seed)
    for _ in range(args.count):
        print(nickname(sep=args.sep))
    return 0 # 0 means success