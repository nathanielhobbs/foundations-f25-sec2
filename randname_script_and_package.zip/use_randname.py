from randname import nickname


print(nickname())