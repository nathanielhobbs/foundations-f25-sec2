author = "Alice"

def addTwoOrMore(a, b, *more_nums):
    total = a + b
    for num in more_nums:      
        total += num
    return total

def multiplyTwoOrMore(a, b, *more_nums):
    total = a * b
    for num in more_nums:  
        total *= num  
    return total

if __name__ == '__main__':
    print(author + ' wrote this')

    print(addTwoOrMore(3,4))
    print(addTwoOrMore(3,4,56))

    print(multiplyTwoOrMore(3,4))
    print(multiplyTwoOrMore(3,4,56))

