from calc import addTwoOrMore, multiplyTwoOrMore
from calc import author as calcAuthor

author = "Bob"

print(author + ' wrote this program')
print(f'{calcAuthor} wrote the calc program')
print(addTwoOrMore(8,8))
print(multiplyTwoOrMore(8,8))