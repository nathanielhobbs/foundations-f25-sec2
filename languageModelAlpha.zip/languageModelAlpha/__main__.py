from .extractTokens import extractTokensFromFile
from .gen import generateSentenceFromTokenList

if __name__ == '__main__':
    tokenList = extractTokensFromFile('input_text.txt')
    print(generateSentenceFromTokenList(tokenList))