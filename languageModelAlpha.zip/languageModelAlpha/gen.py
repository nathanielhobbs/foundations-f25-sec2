import random

def generateSentenceFromTokenList(tokens):
    sentence_tokens =[]
    for _ in range(50):
        choice = random.choice(tokens)
        sentence_tokens.append(choice)

        if choice == ".": 
            break
    if sentence_tokens[-1] != ".":
        sentence_tokens.append(".")
    sentence = " ".join(sentence_tokens)
    
    return sentence