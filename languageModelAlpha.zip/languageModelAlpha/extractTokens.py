def extractTokensFromFile(file_name):
    with open(file_name,'r') as f:
        lines = f.readlines()
        tokens = []
        for s in lines:
            tokens.extend(s.split())

        return tokens